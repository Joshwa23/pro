'use client';

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { CreateJobForm } from '@/components/create-job-form';
import type { Job } from '@/lib/types';


interface CreateJobDialogProps {
    onJobCreated: (newJob: Job) => void;
    children: React.ReactNode;
}

export function CreateJobDialog({ onJobCreated, children }: CreateJobDialogProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleSuccess = (newJob: Job) => {
    onJobCreated(newJob);
    setIsOpen(false);
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl font-semibold text-center">Create Job Opening</DialogTitle>
        </DialogHeader>
        <div className="py-4">
            <CreateJobForm onSuccess={handleSuccess}/>
        </div>
      </DialogContent>
    </Dialog>
  );
}
