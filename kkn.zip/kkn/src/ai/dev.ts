import { config } from 'dotenv';
config();

import '@/ai/flows/skill-extractor.ts';
import '@/ai/flows/talent-matcher.ts';
