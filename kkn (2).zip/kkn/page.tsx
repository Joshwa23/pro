'use client';

import { JobSearchPageContent } from '@/components/job-search-page-content';
import { jobs as initialJobs } from '@/lib/data';
import { Header } from '@/components/header';
import type { Job } from '@/lib/types';
import { useState } from 'react';

export default function Home() {
  const [jobs, setJobs] = useState<Job[]>(initialJobs);

  const handleJobCreated = (newJob: Job) => {
    setJobs(prev => [newJob, ...prev]);
  }

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header />
      <main className="flex-1">
        <JobSearchPageContent initialJobs={jobs} onJobCreated={handleJobCreated} />
      </main>
    </div>
  );
}
