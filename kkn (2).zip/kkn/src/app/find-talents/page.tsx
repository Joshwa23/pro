'use client';

import { useState } from 'react';
import { Header } from '@/components/header';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, User, Search, Briefcase, FileText } from 'lucide-react';
import type { Candidate } from '@/lib/types';
import { handleFindTalent } from '../actions';


export default function FindTalents() {
  const [jobDescription, setJobDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [matchedCandidate, setMatchedCandidate] = useState<Candidate | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!jobDescription) {
      setError('Please provide a job description.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setMatchedCandidate(null);
    try {
      const result = await handleFindTalent(jobDescription);
      if (result.candidate) {
        setMatchedCandidate(result.candidate);
      } else {
        throw new Error('Could not find a suitable candidate.');
      }
    } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
        setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-muted/40">
      <Header />
      <main className="flex-1">
        <div className="container mx-auto py-12">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
              Find Your Next Top Talent
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
              Use our AI-powered search to find the perfect candidate for your open role. Just paste the job description below.
            </p>
          </div>

          <div className="mx-auto mt-10 max-w-2xl">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5"/>
                    Job Description
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  placeholder="Paste the full job description here..."
                  className="min-h-[200px] text-base"
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                />
                <Button onClick={handleSearch} disabled={isLoading} className="w-full">
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="mr-2 h-4 w-4" />
                      Find Best Match
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {error && (
                <div className="mt-6 rounded-md border border-destructive/50 bg-destructive/10 p-4 text-center text-sm text-destructive">
                    {error}
                </div>
            )}

            {matchedCandidate && (
                <div className="mt-12">
                    <h2 className="text-center text-2xl font-bold text-primary">We Found a Match!</h2>
                    <Card className="mt-4 transition-all duration-300 hover:shadow-lg">
                        <CardHeader>
                            <div className="flex items-center gap-4">
                                <Avatar className="h-20 w-20 border-2 border-primary">
                                    <AvatarImage src={matchedCandidate.imageUrl} alt={matchedCandidate.name} />
                                    <AvatarFallback>{matchedCandidate.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div>
                                    <CardTitle className="text-2xl">{matchedCandidate.name}</CardTitle>
                                    <p className="text-md text-muted-foreground">{matchedCandidate.title}</p>
                                </div>
                            </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                            <div>
                                <h3 className="font-semibold flex items-center gap-2"><Briefcase className="h-4 w-4"/> Key Skills</h3>
                                <div className="mt-2 flex flex-wrap gap-2">
                                    {matchedCandidate.skills.map((skill) => (
                                        <Badge key={skill} variant="secondary">{skill}</Badge>
                                    ))}
                                </div>
                            </div>
                             <div>
                                <h3 className="font-semibold flex items-center gap-2"><User className="h-4 w-4"/> Summary</h3>
                                <p className="mt-2 text-sm text-muted-foreground">{matchedCandidate.summary}</p>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
