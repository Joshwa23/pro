'use server';

import { extractSkills } from '@/ai/flows/skill-extractor';
import { findTalent } from '@/ai/flows/talent-matcher';
import type { Job } from '@/lib/types';

export async function handleExtractSkills(jobDescription: string) {
  try {
    const result = await extractSkills({ jobDescription });
    return { skills: result.skills };
  } catch (error) {
    console.error('Error extracting skills:', error);
    throw new Error('Failed to analyze skills. Please try again later.');
  }
}

export async function handleFindTalent(jobDescription: string) {
    try {
        const result = await findTalent({ jobDescription });
        return { candidate: result.candidate };
    } catch (error) {
        console.error('Error finding talent:', error);
        throw new Error('Failed to find a matching candidate. Please try again later.');
    }
}

export async function createJob(
  newJobData: Omit<Job, 'id' | 'deadline' | 'applyUrl' | 'logoUrl' | 'skills'>
): Promise<{job: Job, error: null} | {job: null, error: string}> {
    try {
        const { skills } = await extractSkills({ jobDescription: newJobData.description });
        const newJob: Job = {
            ...newJobData,
            id: Date.now().toString(), // Using timestamp for a unique ID
            deadline: new Date(),
            applyUrl: '#',
            logoUrl: `https://placehold.co/100x100.png?text=${newJobData.company.charAt(0)}`,
            skills: skills,
        };
         // In a real app, you would save this to a database.
        console.log('New job created:', newJob);
        return { job: newJob, error: null };
    } catch (error) {
        console.error('Failed to create job', error);
        const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred.';
        return { job: null, error: `There was an issue creating the job: ${errorMessage}` };
    }
}
